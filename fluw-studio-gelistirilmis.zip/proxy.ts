import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { QUICK_ADMIN_COOKIE, getExpectedQuickAdminToken } from '@/lib/admin-session'

const neonMiddleware = auth.middleware({
  loginUrl: '/admin/sign-in',
  publicRoutes: ['/', '/admin-giris', '/admin/sign-in', '/admin/sign-up', '/api/shopier/callback'],
})

export default async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Allow magic login route directly
  if (pathname === '/admin-giris' || pathname.startsWith('/admin-giris/')) {
    return NextResponse.next()
  }

  // If valid quick-admin cookie exists, allow /admin routes without forcing Neon login redirect
  if (pathname.startsWith('/admin')) {
    const cookieToken = request.cookies.get(QUICK_ADMIN_COOKIE)?.value
    if (cookieToken && cookieToken === getExpectedQuickAdminToken()) {
      if (pathname === '/admin/sign-in' || pathname === '/admin/sign-up') {
        return NextResponse.redirect(new URL('/admin', request.url))
      }
      return NextResponse.next()
    }
  }

  return neonMiddleware(request)
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)'],
}
