import { NextRequest, NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import {
  QUICK_ADMIN_COOKIE,
  getExpectedQuickAdminToken,
  getMagicAdminKey,
} from '@/lib/admin-session'

export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  const url = new URL(request.url)
  const magicKey = getMagicAdminKey()
  const rawQuery = url.search.startsWith('?') ? url.search.slice(1) : ''

  // Supports /admin-giris?omerasafsabaz.dev, /admin-giris?omerasafsabaz.dev=, or /admin-giris?key=omerasafsabaz.dev
  const isAuthorized =
    url.searchParams.has(magicKey) ||
    url.searchParams.get('key') === magicKey ||
    decodeURIComponent(rawQuery) === magicKey

  if (!isAuthorized) {
    return NextResponse.redirect(new URL('/admin/sign-in?error=gecersiz-baglanti', request.url))
  }

  const cookieStore = await cookies()
  cookieStore.set(QUICK_ADMIN_COOKIE, getExpectedQuickAdminToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7, // 7 gün geçerli oturum
  })

  return NextResponse.redirect(new URL('/admin', request.url))
}
