'use server'

import { randomUUID } from 'node:crypto'
import { eq } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { QUICK_ADMIN_COOKIE, getAdminUser } from '@/lib/admin-session'
import { db } from '@/lib/db'
import { products } from '@/lib/db/schema'

async function requireAdmin() {
  const adminUser = await getAdminUser()
  if (!adminUser) {
    redirect('/admin/sign-in')
  }
  return adminUser
}

function field(formData: FormData, name: string) {
  const value = formData.get(name)
  return typeof value === 'string' ? value.trim() : ''
}

function shopierUrl(value: string) {
  if (!value) return null
  try {
    const url = new URL(value)
    if (url.protocol !== 'https:' || !(url.hostname === 'shopier.com' || url.hostname.endsWith('.shopier.com'))) return null
    return url.toString()
  } catch {
    return null
  }
}

function productInput(formData: FormData) {
  const name = field(formData, 'name')
  const category = field(formData, 'category')
  const description = field(formData, 'description')
  const imageUrl = field(formData, 'imageUrl')
  const toneValue = field(formData, 'tone')
  const tag = field(formData, 'tag')
  const shopierLink = field(formData, 'shopierUrl')
  const price = Number(field(formData, 'price'))

  if (!name || name.length > 120) throw new Error('Ürün adı 1–120 karakter olmalıdır.')
  if (!category || category.length > 60) throw new Error('Kategori 1–60 karakter olmalıdır.')
  if (!Number.isSafeInteger(price) || price <= 0 || price > 100000000) throw new Error('Geçerli bir tam sayı fiyat girin.')
  if (description.length > 2000 || tag.length > 40) throw new Error('Açıklama veya etiket çok uzun.')
  if (imageUrl && !((imageUrl.startsWith('/') && !imageUrl.startsWith('//')) || imageUrl.startsWith('https://'))) throw new Error('Görsel bağlantısı https:// ile başlamalı veya yerel bir yol olmalıdır.')
  if (shopierLink && !shopierUrl(shopierLink)) throw new Error('Shopier bağlantısı https://shopier.com adresinden olmalıdır.')

  return {
    name,
    category,
    description,
    price,
    imageUrl,
    tone: ['blue', 'pink', 'green', 'yellow'].includes(toneValue) ? toneValue : 'blue',
    tag: tag || null,
    shopierUrl: shopierLink ? shopierUrl(shopierLink) : null,
    active: field(formData, 'active') === 'on',
  }
}

function slugify(value: string) {
  return value.toLocaleLowerCase('tr-TR')
    .replaceAll('ı', 'i')
    .replaceAll('ğ', 'g')
    .replaceAll('ü', 'u')
    .replaceAll('ş', 's')
    .replaceAll('ö', 'o')
    .replaceAll('ç', 'c')
    .normalize('NFKD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
}

export async function createProduct(formData: FormData) {
  await requireAdmin()
  const values = productInput(formData)
  const slug = `${slugify(values.name)}-${randomUUID().slice(0, 8)}`

  await db.insert(products).values({ id: randomUUID(), slug, ...values })
  revalidatePath('/')
  revalidatePath('/admin')
}

export async function updateProduct(formData: FormData) {
  await requireAdmin()
  const id = field(formData, 'id')
  if (!id || id.length > 100) throw new Error('Ürün bulunamadı.')
  const values = productInput(formData)
  const slug = `${slugify(values.name)}-${id.slice(0, 8)}`

  await db.update(products).set({ ...values, slug, updatedAt: new Date() }).where(eq(products.id, id))
  revalidatePath('/')
  revalidatePath('/admin')
}

export async function toggleProductStatus(formData: FormData) {
  await requireAdmin()
  const id = field(formData, 'id')
  const nextActive = field(formData, 'nextActive') === 'true'
  if (!id || id.length > 100) throw new Error('Ürün bulunamadı.')

  await db.update(products).set({ active: nextActive, updatedAt: new Date() }).where(eq(products.id, id))
  revalidatePath('/')
  revalidatePath('/admin')
}

export async function duplicateProduct(formData: FormData) {
  await requireAdmin()
  const id = field(formData, 'id')
  if (!id || id.length > 100) throw new Error('Ürün bulunamadı.')

  const existing = await db.select().from(products).where(eq(products.id, id)).limit(1)
  const source = existing[0]
  if (!source) throw new Error('Kopyalanacak ürün bulunamadı.')

  const newId = randomUUID()
  const newName = `${source.name} (Kopya)`
  const slug = `${slugify(newName)}-${newId.slice(0, 8)}`

  await db.insert(products).values({
    id: newId,
    slug,
    name: newName,
    category: source.category,
    description: source.description,
    price: source.price,
    imageUrl: source.imageUrl,
    tone: source.tone,
    tag: source.tag,
    shopierUrl: source.shopierUrl,
    active: false,
  })

  revalidatePath('/')
  revalidatePath('/admin')
}

export async function deleteProduct(formData: FormData) {
  await requireAdmin()
  const id = field(formData, 'id')
  if (!id || id.length > 100) throw new Error('Ürün bulunamadı.')

  await db.delete(products).where(eq(products.id, id))
  revalidatePath('/')
  revalidatePath('/admin')
}

export async function signOutAdmin() {
  await requireAdmin()
  const cookieStore = await cookies()
  cookieStore.delete(QUICK_ADMIN_COOKIE)

  try {
    await auth.signOut()
  } catch {
    // Ignore if signed in only via magic link
  }

  redirect('/admin/sign-in')
}
