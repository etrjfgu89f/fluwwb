'use server'

import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'

export type SignUpState = { error: string | null }

export async function createAdminAccount(_previousState: SignUpState, formData: FormData): Promise<SignUpState> {
  const email = String(formData.get('email') ?? '').trim()
  const password = String(formData.get('password') ?? '')
  const confirmPassword = String(formData.get('confirmPassword') ?? '')
  const adminEmail = process.env.FLUW_ADMIN_EMAIL?.trim().toLocaleLowerCase('en-US')

  if (!email || !adminEmail || email.toLocaleLowerCase('en-US') !== adminEmail) {
    return { error: 'Bu e-posta adresi yönetici hesabı için tanımlı değil.' }
  }
  if (password.length < 8 || password.length > 128) return { error: 'Şifre 8–128 karakter arasında olmalıdır.' }
  if (password !== confirmPassword) return { error: 'Şifreler eşleşmiyor.' }

  try {
    const { error } = await auth.signUp.email({ email, password, name: 'Fluw Studio Admin' })
    if (error) return { error: 'Hesap oluşturulamadı. E-posta kayıtlı olabilir; giriş yapmayı deneyin.' }
  } catch {
    return { error: 'Hesap oluşturma şu anda tamamlanamadı. Lütfen tekrar deneyin.' }
  }

  redirect('/admin')
}
