import { redirect } from 'next/navigation'
import { AdminSignUp } from '@/components/admin-sign-up'
import { getAdminUser } from '@/lib/admin-session'

export const dynamic = 'force-dynamic'

export default async function AdminSignUpPage() {
  const adminUser = await getAdminUser()
  if (adminUser) {
    redirect('/admin')
  }

  return <AdminSignUp />
}
