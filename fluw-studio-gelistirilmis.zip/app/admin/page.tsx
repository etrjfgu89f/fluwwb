import { redirect } from 'next/navigation'
import { AdminPanel } from '@/components/admin-panel'
import { getAdminUser } from '@/lib/admin-session'
import { getAdminProducts, getProducts } from '@/lib/products'
import { getShopierOrders } from '@/lib/shopier'

export const dynamic = 'force-dynamic'

export default async function AdminPage() {
  const adminUser = await getAdminUser()
  if (!adminUser) {
    redirect('/admin/sign-in')
  }

  await getProducts()
  const [products, shopierResult] = await Promise.all([getAdminProducts(), getShopierOrders()])

  return (
    <AdminPanel
      products={products}
      orders={shopierResult.orders}
      orderError={shopierResult.error}
      email={adminUser.email}
      authMethod={adminUser.method}
    />
  )
}
