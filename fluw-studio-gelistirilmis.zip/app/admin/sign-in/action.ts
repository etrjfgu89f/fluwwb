'use server'

import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'

export type SignInState = { error: string | null }

export async function signInAdmin(_previousState: SignInState, formData: FormData): Promise<SignInState> {
  const email = String(formData.get('email') ?? '').trim()
  const password = String(formData.get('password') ?? '')
  const adminEmail = process.env.FLUW_ADMIN_EMAIL?.trim().toLocaleLowerCase('en-US')

  if (!email || !password || !adminEmail || email.toLocaleLowerCase('en-US') !== adminEmail) {
    return { error: 'E-posta veya şifre hatalı.' }
  }

  try {
    const { error } = await auth.signIn.email({ email, password })
    if (error) return { error: 'E-posta veya şifre hatalı.' }
  } catch {
    return { error: 'Giriş şu anda tamamlanamadı. Lütfen tekrar deneyin.' }
  }

  redirect('/admin')
}
