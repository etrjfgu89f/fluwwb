import { redirect } from 'next/navigation'
import { AdminSignIn } from '@/components/admin-sign-in'
import { getAdminUser } from '@/lib/admin-session'

export const dynamic = 'force-dynamic'

export default async function AdminSignInPage() {
  const adminUser = await getAdminUser()
  if (adminUser) {
    redirect('/admin')
  }

  return <AdminSignIn />
}
