import { desc, eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { products } from '@/lib/db/schema'

const starterProducts = [
  { id: 'fluw-loop-vazo', slug: 'loop-vazo', name: 'Loop Vazo', category: 'Objeler', price: 890, imageUrl: '/product-vase.png', tone: 'blue', tag: 'Çok sevilen', description: 'Katmanlı yüzeyiyle her köşeye karakter katan Loop Vazo.' },
  { id: 'fluw-mantar-lamba', slug: 'mantar-masa-lambasi', name: 'Mantar Masa Lambası', category: 'Aydınlatma', price: 1450, imageUrl: '/product-lamp.png', tone: 'pink', tag: 'Yeni', description: 'Yumuşak ışığı ve heykelsi formuyla masanın yeni favorisi.' },
  { id: 'fluw-knot-heykel', slug: 'knot-heykel', name: 'Knot Heykel', category: 'Objeler', price: 760, imageUrl: '/product-knot.png', tone: 'green', tag: null, description: 'Tek bir çizginin üç boyutta aldığı oyunbaz form.' },
  { id: 'fluw-dalga-kase', slug: 'dalga-kase', name: 'Dalga Kase', category: 'Ev & Yaşam', price: 680, imageUrl: '/product-bowl.png', tone: 'yellow', tag: null, description: 'Günlük küçük eşyalar için dalgalı, işlevsel bir eşlikçi.' },
]

export async function getProducts() {
  const existing = await db.select({ id: products.id }).from(products).limit(1)
  if (existing.length === 0) {
    await db.insert(products).values(starterProducts).onConflictDoNothing()
  }

  return db.select().from(products).where(eq(products.active, true)).orderBy(desc(products.createdAt))
}

export async function getAdminProducts() {
  return db.select().from(products).orderBy(desc(products.createdAt))
}
