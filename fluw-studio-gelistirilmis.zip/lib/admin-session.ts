import { cookies } from 'next/headers'
import { auth } from '@/lib/auth'

export const QUICK_ADMIN_COOKIE = 'fluw_quick_admin'

export function getExpectedQuickAdminToken() {
  return process.env.ADMIN_SESSION_SECRET?.trim() || 'fluw-omerasafsabaz-dev-secret-2026'
}

export function getMagicAdminKey() {
  return process.env.ADMIN_MAGIC_KEY?.trim() || 'omerasafsabaz.dev'
}

export async function isQuickAdminAuthenticated(): Promise<boolean> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(QUICK_ADMIN_COOKIE)?.value
    return Boolean(token && token === getExpectedQuickAdminToken())
  } catch {
    return false
  }
}

export async function getAdminUser(): Promise<{ email: string; method: 'magic-link' | 'neon-auth' } | null> {
  const adminEmail = process.env.FLUW_ADMIN_EMAIL?.trim() || 'omerasafsabaz@gmail.com'

  if (await isQuickAdminAuthenticated()) {
    return { email: adminEmail, method: 'magic-link' }
  }

  try {
    const { data } = await auth.getSession()
    const envAdminEmail = process.env.FLUW_ADMIN_EMAIL?.trim().toLocaleLowerCase('en-US')
    if (data?.user && envAdminEmail && data.user.email.toLocaleLowerCase('en-US') === envAdminEmail) {
      return { email: data.user.email, method: 'neon-auth' }
    }
  } catch {
    // Neon auth fallback ignored if quick session is used
  }

  return null
}
