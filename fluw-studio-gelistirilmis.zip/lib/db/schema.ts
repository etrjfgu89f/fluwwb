import { boolean, integer, jsonb, pgTable, text, timestamp } from 'drizzle-orm/pg-core'

export const products = pgTable('products', {
  id: text('id').primaryKey(),
  slug: text('slug').notNull().unique(),
  name: text('name').notNull(),
  category: text('category').notNull(),
  description: text('description').notNull().default(''),
  price: integer('price').notNull(),
  imageUrl: text('image_url').notNull().default(''),
  tone: text('tone').notNull().default('blue'),
  tag: text('tag'),
  shopierUrl: text('shopier_url'),
  active: boolean('active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const orders = pgTable('orders', {
  id: text('id').primaryKey(),
  shopierOrderId: text('shopier_order_id').unique(),
  customerName: text('customer_name'),
  customerEmail: text('customer_email'),
  totalAmount: integer('total_amount').notNull().default(0),
  currency: text('currency').notNull().default('TRY'),
  status: text('status').notNull().default('pending'),
  items: jsonb('items').notNull().default([]),
  shopierPayload: jsonb('shopier_payload'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})
