type ShopierOrderRecord = Record<string, unknown>

export type ShopierOrder = {
  id: string
  customer: string
  email: string
  total: number | null
  currency: string
  status: string
  createdAt: string | null
  itemSummary: string
}

function asRecord(value: unknown): ShopierOrderRecord | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as ShopierOrderRecord
    : null
}

function firstString(...values: unknown[]) {
  return values.find((value): value is string => typeof value === 'string' && value.length > 0) ?? ''
}

function firstNumber(...values: unknown[]) {
  const value = values.find((candidate) => typeof candidate === 'number' || (typeof candidate === 'string' && candidate.trim() !== ''))
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value === 'string') {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : null
  }
  return null
}

function normalizeOrder(value: unknown, index: number): ShopierOrder | null {
  const order = asRecord(value)
  if (!order) return null

  const customer = asRecord(order.customer) ?? asRecord(order.buyer) ?? {}
  const items = Array.isArray(order.items) ? order.items : Array.isArray(order.products) ? order.products : []
  const names = items.map((item) => {
    const record = asRecord(item)
    return record ? firstString(record.name, record.title, record.productName) : ''
  }).filter(Boolean)

  return {
    id: firstString(order.orderId, order.id, order.orderNumber) || `order-${index + 1}`,
    customer: firstString(order.customerName, order.name, customer.name, customer.fullName) || 'Shopier müşterisi',
    email: firstString(order.customerEmail, order.email, customer.email),
    total: firstNumber(order.totalAmount, order.amount, order.total, order.grandTotal),
    currency: firstString(order.currency, order.currencyCode) || 'TRY',
    status: firstString(order.status, order.paymentStatus, order.fulfillmentStatus) || 'Beklemede',
    createdAt: firstString(order.createdAt, order.orderDate, order.created, order.date) || null,
    itemSummary: names.join(', ') || `${items.length || 1} ürün`,
  }
}

export async function getShopierOrders() {
  const token = process.env.SHOPIER_PAT
  if (!token) return { orders: [] as ShopierOrder[], error: 'Shopier bağlantısı için PAT yapılandırılmamış.' }

  const now = new Date()
  const start = new Date(now)
  start.setDate(now.getDate() - 30)
  const iso = (date: Date) => date.toISOString().replace(/\.\d{3}Z$/, 'Z')
  const endpoint = new URL('https://api.shopier.com/v1/orders')
  endpoint.searchParams.set('dateStart', iso(start))
  endpoint.searchParams.set('dateEnd', iso(now))
  endpoint.searchParams.set('limit', '50')
  endpoint.searchParams.set('page', '1')

  try {
    const response = await fetch(endpoint, {
      headers: { Accept: 'application/json', Authorization: `Bearer ${token}` },
      cache: 'no-store',
      signal: AbortSignal.timeout(10000),
    })

    if (!response.ok) {
      console.error('[shopier] Order request failed with status', response.status)
      return { orders: [] as ShopierOrder[], error: 'Shopier siparişleri şu anda alınamıyor. Bağlantı ayarlarını kontrol edin.' }
    }

    const payload: unknown = await response.json()
    const record = asRecord(payload)
    const rows = Array.isArray(payload)
      ? payload
      : Array.isArray(record?.data)
        ? record.data
        : Array.isArray(record?.orders)
          ? record.orders
          : []

    return { orders: rows.map(normalizeOrder).filter((order): order is ShopierOrder => order !== null), error: null }
  } catch (error) {
    console.error('[shopier] Order request failed', error instanceof Error ? error.name : 'unknown error')
    return { orders: [] as ShopierOrder[], error: 'Shopier siparişleri şu anda alınamıyor. Lütfen daha sonra tekrar deneyin.' }
  }
}
