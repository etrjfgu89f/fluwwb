'use client'

import { useEffect, useMemo, useState } from 'react'
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Eye,
  Menu,
  Minus,
  Plus,
  Search,
  ShoppingBag,
  Sparkles,
  Truck,
  X,
} from 'lucide-react'

type Product = {
  id: string
  slug: string
  name: string
  category: string
  description: string
  price: number
  imageUrl: string
  tone: string
  tag: string | null
  shopierUrl: string | null
}

type CartItem = {
  product: Product
  quantity: number
}

const FREE_SHIPPING_THRESHOLD = 1500
const CART_STORAGE_KEY = 'fluw_studio_cart_v1'

export function Storefront({ products }: { products: Product[] }) {
  const [category, setCategory] = useState('Tümü')
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured')
  const [cart, setCart] = useState<CartItem[]>([])
  const [cartHydrated, setCartHydrated] = useState(false)
  const [cartOpen, setCartOpen] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [added, setAdded] = useState<string | null>(null)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  // Sepeti localStorage'dan yükle
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(CART_STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved) as Array<{ id: string; quantity: number }>
        if (Array.isArray(parsed)) {
          const restored: CartItem[] = parsed
            .map((entry) => {
              const found = products.find((p) => p.id === entry.id)
              return found && entry.quantity > 0 ? { product: found, quantity: entry.quantity } : null
            })
            .filter((item): item is CartItem => item !== null)
          setCart(restored)
        }
      }
    } catch {
      // Storage erişim hatası yoksayılır
    } finally {
      setCartHydrated(true)
    }
  }, [products])

  // Sepet değiştiğinde kaydet
  useEffect(() => {
    if (!cartHydrated) return
    try {
      const payload = cart.map((item) => ({ id: item.product.id, quantity: item.quantity }))
      window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(payload))
    } catch {
      // Storage erişim hatası yoksayılır
    }
  }, [cart, cartHydrated])

  // ESC tuşu ile modal/çekmece kapatma
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setCartOpen(false)
        setSelectedProduct(null)
        setMobileMenuOpen(false)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const categories = useMemo(
    () => ['Tümü', ...new Set(products.map((product) => product.category))],
    [products],
  )

  const visibleProducts = useMemo(() => {
    const filtered = products.filter(
      (product) =>
        (category === 'Tümü' || product.category === category) &&
        (product.name.toLocaleLowerCase('tr').includes(query.toLocaleLowerCase('tr')) ||
          product.description.toLocaleLowerCase('tr').includes(query.toLocaleLowerCase('tr'))),
    )

    if (sortBy === 'price-asc') {
      return [...filtered].sort((a, b) => a.price - b.price)
    }
    if (sortBy === 'price-desc') {
      return [...filtered].sort((a, b) => b.price - a.price)
    }
    return filtered
  }, [products, category, query, sortBy])

  const addToCart = (product: Product, openDrawer = false) => {
    setCart((current) => {
      const existingIndex = current.findIndex((item) => item.product.id === product.id)
      if (existingIndex >= 0) {
        const updated = [...current]
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + 1,
        }
        return updated
      }
      return [...current, { product, quantity: 1 }]
    })
    setAdded(product.id)
    window.setTimeout(() => setAdded(null), 1300)
    if (openDrawer) {
      setCartOpen(true)
    }
  }

  const updateQuantity = (productId: string, delta: number) => {
    setCart((current) =>
      current
        .map((item) =>
          item.product.id === productId ? { ...item, quantity: item.quantity + delta } : item,
        )
        .filter((item) => item.quantity > 0),
    )
  }

  const removeFromCart = (productId: string) => {
    setCart((current) => current.filter((item) => item.product.id !== productId))
  }

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)
  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0)
  const remainingForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - total)
  const shippingProgress = Math.min(100, Math.round((total / FREE_SHIPPING_THRESHOLD) * 100))

  return (
    <main>
      <div className="announcement">
        Tasarımın yeni haliyle tanış <span>·</span> 1.500₺ üzeri ücretsiz kargo <ArrowRight size={13} />
      </div>

      <header className="site-header">
        <a className="wordmark" href="#top" aria-label="Fluw Studio ana sayfa">
          fluw<span>®</span>
        </a>
        <nav className="desktop-nav" aria-label="Ana menü">
          <a href="#shop">Mağaza</a>
          <a href="#story">Hikâyemiz</a>
          <a href="#footer">İletişim</a>
        </nav>
        <div className="header-actions">
          <button
            className="icon-button search-trigger"
            aria-label="Arama"
            onClick={() => setSearchOpen(!searchOpen)}
          >
            <Search size={18} />
          </button>
          <button
            className="cart-trigger"
            onClick={() => setCartOpen(true)}
            aria-label={`Sepet, ${totalItems} ürün`}
          >
            <ShoppingBag size={17} />
            <span>Sepet</span>
            <b>{totalItems}</b>
          </button>
          <button
            className="icon-button mobile-menu"
            aria-label="Menüyü aç"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu size={20} />
          </button>
        </div>
      </header>

      {searchOpen && (
        <div className="search-row">
          <Search size={17} />
          <input
            autoFocus
            aria-label="Ürün ara"
            placeholder="Ne aramıştın? (Vazo, lamba, kase...)"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          <button
            aria-label="Aramayı kapat"
            onClick={() => {
              setSearchOpen(false)
              setQuery('')
            }}
          >
            <X size={17} />
          </button>
        </div>
      )}

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">
            <span className="eyebrow-dot" /> İYİ FİKİRLER, KATMAN KATMAN
          </p>
          <h1>
            Hayal et.
            <br />
            <em>Katmanla.</em>
          </h1>
          <p className="hero-description">
            Gündelik hayata biraz daha karakter katan, özenle tasarlanmış 3D baskı objeler.
          </p>
          <a className="hero-link" href="#shop">
            Koleksiyonu keşfet <ArrowDown size={15} />
          </a>
          <span className="hero-index">01 — 0{Math.max(4, products.length)}</span>
        </div>
        <div className="hero-art">
          <img
            src="/fluw-studio.png"
            alt="Renkli 3D baskı tasarımlarından oluşan Fluw Studio koleksiyonu"
          />
          <div className="hero-sticker">
            DESIGNED
            <br />
            TO MAKE
            <br />
            YOU SMILE <ArrowUpRight size={18} />
          </div>
          <span className="art-caption">STÜDYODAN ÇIKTI, SANA GELİYOR.</span>
        </div>
      </section>

      <section className="ticker" aria-label="Fluw Studio özellikleri">
        <div>
          FİKİRDEN NESNEYE <span>✳</span> YEREL ÜRETİM <span>✳</span> DAHA AZ ATIK <span>✳</span> SENİN İÇİN BASILDI{' '}
          <span>✳</span> FİKİRDEN NESNEYE <span>✳</span> YEREL ÜRETİM <span>✳</span> DAHA AZ ATIK <span>✳</span>
        </div>
      </section>

      <section className="shop-section" id="shop">
        <div className="section-heading">
          <div>
            <p className="eyebrow">KÜÇÜK SERİLER, BÜYÜK FİKİRLER</p>
            <h2>
              Şimdi <em>rafta.</em>
            </h2>
          </div>
          <div className="shop-sort-wrap">
            <select
              aria-label="Sıralama"
              className="shop-sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'featured' | 'price-asc' | 'price-desc')}
            >
              <option value="featured">Öne çıkanlar</option>
              <option value="price-asc">Fiyat: Artan</option>
              <option value="price-desc">Fiyat: Azalan</option>
            </select>
          </div>
        </div>

        <div className="shop-toolbar">
          <div className="category-list" role="group" aria-label="Ürün kategorisi">
            {categories.map((item) => (
              <button
                key={item}
                className={category === item ? 'category active' : 'category'}
                onClick={() => setCategory(item)}
              >
                {item}
              </button>
            ))}
          </div>
          <span className="product-count">
            {visibleProducts.length < 10 ? `0${visibleProducts.length}` : visibleProducts.length} ÜRÜN
          </span>
        </div>

        <div className="product-grid">
          {visibleProducts.map((product, index) => (
            <article className="product-card" key={product.id}>
              <div className={`product-image ${product.tone}`}>
                <img
                  src={product.imageUrl || '/placeholder.svg'}
                  alt={product.name}
                  loading="lazy"
                  onClick={() => setSelectedProduct(product)}
                  style={{ cursor: 'pointer' }}
                />
                {product.tag && <span className="product-tag">{product.tag}</span>}
                <button
                  type="button"
                  className="quick-inspect"
                  onClick={() => setSelectedProduct(product)}
                  aria-label={`${product.name} detaylarını incele`}
                  title="Hızlı incele"
                >
                  <Eye size={15} />
                </button>
                <button
                  className={`quick-add ${added === product.id ? 'added' : ''}`}
                  onClick={() => addToCart(product)}
                  aria-label={`${product.name} sepete ekle`}
                >
                  {added === product.id ? <Check size={18} /> : <span>+</span>}
                </button>
                <span className="product-number">{index + 1 < 10 ? `0${index + 1}` : index + 1}</span>
              </div>
              <div className="product-info">
                <div>
                  <p className="product-category">{product.category}</p>
                  <h3 onClick={() => setSelectedProduct(product)} style={{ cursor: 'pointer' }}>
                    {product.name}
                  </h3>
                </div>
                <span className="product-price">{product.price.toLocaleString('tr-TR')}₺</span>
              </div>
              {product.shopierUrl ? (
                <a
                  className="product-shopier-link"
                  href={product.shopierUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Shopier&apos;de sipariş ver <ArrowUpRight size={14} />
                </a>
              ) : (
                <button
                  type="button"
                  className="product-detail-trigger"
                  onClick={() => setSelectedProduct(product)}
                >
                  Detayları incele <ArrowUpRight size={14} />
                </button>
              )}
            </article>
          ))}
        </div>

        {visibleProducts.length === 0 && (
          <p className="empty-results">Aramana uygun ürün bulamadık. Başka bir şey dene.</p>
        )}
      </section>

      <section className="manifesto" id="story">
        <div className="manifesto-mark">f.</div>
        <div>
          <p className="eyebrow">FLUW STUDIO HAKKINDA</p>
          <h2>
            Biraz oyun,
            <br />
            bolca <em>iyi fikir.</em>
          </h2>
        </div>
        <div className="manifesto-text">
          <p>
            Fluw, dijital dünyada başlayan fikirleri günlük hayatın bir parçası hâline getiriyor. Her parça,
            İstanbul’daki stüdyomuzda ihtiyaç oldukça üretiliyor.
          </p>
          <a href="#footer">
            Bizi daha yakından tanı <ArrowUpRight size={15} />
          </a>
        </div>
        <span className="manifesto-spark">✳</span>
      </section>

      <section className="promise-row">
        <div>
          <span className="promise-icon">01</span>
          <strong>İhtiyaç oldukça üretilir</strong>
          <p>Fazla üretim yok, daha az atık var.</p>
        </div>
        <div>
          <span className="promise-icon">02</span>
          <strong>Her parça kendine özgü</strong>
          <p>Katman izleri, tasarımın bir parçası.</p>
        </div>
        <div>
          <span className="promise-icon">03</span>
          <strong>Özenle paketlenir</strong>
          <p>Stüdyodan kapına, sevgiyle.</p>
        </div>
      </section>

      <footer id="footer">
        <a className="wordmark footer-logo" href="#top">
          fluw<span>®</span>
        </a>
        <p>Güzel fikirler, katman katman.</p>
        <div className="footer-links">
          <a href="#shop">Mağaza</a>
          <a href="mailto:merhaba@fluw.studio">Bize yaz</a>
          <a href="#story">Instagram ↗</a>
        </div>
        <span className="copyright">© 2026 FLUW STUDIO · İSTANBUL</span>
      </footer>

      {/* Mobil Menü Çekmecesi */}
      {mobileMenuOpen && (
        <div
          className="overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setMobileMenuOpen(false)
          }}
        >
          <aside className="mobile-drawer" role="dialog" aria-modal="true" aria-label="Mobil menü">
            <div className="cart-heading">
              <span className="wordmark">
                fluw<span>®</span>
              </span>
              <button className="icon-button" onClick={() => setMobileMenuOpen(false)} aria-label="Menüyü kapat">
                <X size={20} />
              </button>
            </div>
            <nav className="mobile-drawer-links">
              <a href="#shop" onClick={() => setMobileMenuOpen(false)}>
                Mağaza
              </a>
              <a href="#story" onClick={() => setMobileMenuOpen(false)}>
                Hikâyemiz
              </a>
              <a href="#footer" onClick={() => setMobileMenuOpen(false)}>
                İletişim
              </a>
            </nav>
            <div className="mobile-drawer-footer">
              <p>1.500₺ üzeri siparişlerde ücretsiz kargo.</p>
            </div>
          </aside>
        </div>
      )}

      {/* Ürün Hızlı İnceleme Modalı */}
      {selectedProduct && (
        <div
          className="product-modal-overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setSelectedProduct(null)
          }}
        >
          <div className="product-modal" role="dialog" aria-modal="true" aria-label={selectedProduct.name}>
            <button
              type="button"
              className="product-modal-close"
              onClick={() => setSelectedProduct(null)}
              aria-label="Kapat"
            >
              <X size={18} />
            </button>
            <div className={`product-modal-media ${selectedProduct.tone}`}>
              <img src={selectedProduct.imageUrl || '/placeholder.svg'} alt={selectedProduct.name} />
              {selectedProduct.tag && <span className="product-tag">{selectedProduct.tag}</span>}
            </div>
            <div className="product-modal-body">
              <p className="eyebrow">{selectedProduct.category.toLocaleUpperCase('tr')}</p>
              <h2>{selectedProduct.name}</h2>
              <p className="product-modal-price">{selectedProduct.price.toLocaleString('tr-TR')}₺</p>
              <p className="product-modal-desc">
                {selectedProduct.description ||
                  'Stüdyomuzda çevre dostu PLA filament ile katman katman üretilen özel tasarım obje.'}
              </p>
              <div className="product-modal-specs">
                <span>
                  <Sparkles size={13} /> Sipariş üzerine taze 3D baskı
                </span>
                <span>
                  <Truck size={13} /> 2–4 iş günü içinde kargoda
                </span>
              </div>
              <div className="product-modal-actions">
                <button
                  type="button"
                  className="modal-add-cart-btn"
                  onClick={() => {
                    addToCart(selectedProduct, true)
                    setSelectedProduct(null)
                  }}
                >
                  Sepete ekle · {selectedProduct.price.toLocaleString('tr-TR')}₺
                </button>
                {selectedProduct.shopierUrl && (
                  <a
                    className="checkout-button"
                    href={selectedProduct.shopierUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Shopier ile hemen al <ArrowUpRight size={16} />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Alışveriş Sepeti Çekmecesi */}
      {cartOpen && (
        <div
          className="overlay"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setCartOpen(false)
          }}
        >
          <aside className="cart-panel" role="dialog" aria-modal="true" aria-label="Alışveriş sepeti">
            <div className="cart-heading">
              <div>
                <p className="eyebrow">BİR SONRAKİ FAVORİN</p>
                <h2>
                  Sepetin <em>({totalItems})</em>
                </h2>
              </div>
              <button className="icon-button" onClick={() => setCartOpen(false)} aria-label="Sepeti kapat">
                <X size={20} />
              </button>
            </div>

            {/* Ücretsiz Kargo İlerleme Çubuğu */}
            {cart.length > 0 && (
              <div className="shipping-bar-box">
                <p>
                  {remainingForFreeShipping === 0 ? (
                    <>
                      <strong>Tebrikler!</strong> Siparişin ücretsiz kargo hakkı kazandı.
                    </>
                  ) : (
                    <>
                      Ücretsiz kargo için <strong>{remainingForFreeShipping.toLocaleString('tr-TR')}₺</strong> daha ekle.
                    </>
                  )}
                </p>
                <div className="shipping-bar-track">
                  <div className="shipping-bar-fill" style={{ width: `${shippingProgress}%` }} />
                </div>
              </div>
            )}

            {cart.length === 0 ? (
              <div className="cart-empty">
                <span>✳</span>
                <p>Sepetin şimdilik boş.</p>
                <button onClick={() => setCartOpen(false)}>
                  Ürünlere göz at <ArrowRight size={15} />
                </button>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map(({ product, quantity }) => (
                    <div className="cart-item" key={product.id}>
                      <img src={product.imageUrl || '/placeholder.svg'} alt="" />
                      <div>
                        <strong>{product.name}</strong>
                        <span>{(product.price * quantity).toLocaleString('tr-TR')}₺</span>
                        <div className="cart-qty-controls">
                          <button
                            type="button"
                            aria-label="Adet azalt"
                            onClick={() => updateQuantity(product.id, -1)}
                          >
                            <Minus size={12} />
                          </button>
                          <b>{quantity}</b>
                          <button
                            type="button"
                            aria-label="Adet artır"
                            onClick={() => updateQuantity(product.id, 1)}
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        {product.shopierUrl && (
                          <a
                            className="cart-shopier-link"
                            href={product.shopierUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            Shopier&apos;de al ↗
                          </a>
                        )}
                      </div>
                      <button
                        aria-label={`${product.name} ürününü kaldır`}
                        onClick={() => removeFromCart(product.id)}
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ))}
                </div>
                <div className="cart-bottom">
                  <div className="cart-total">
                    <span>Ara toplam</span>
                    <strong>{total.toLocaleString('tr-TR')}₺</strong>
                  </div>
                  <p>
                    {remainingForFreeShipping === 0
                      ? 'Ücretsiz kargo uygulandı.'
                      : 'Kargo ödeme adımında hesaplanır.'}
                  </p>
                  {cart.length === 1 && cart[0].product.shopierUrl ? (
                    <a
                      className="checkout-button"
                      href={cart[0].product.shopierUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Shopier&apos;de ödemeye geç <ArrowRight size={17} />
                    </a>
                  ) : (
                    <p className="checkout-guidance">
                      Her ürünün ödemesi kendi Shopier bağlantısından açılır. Ürün bağlantılarını yukarıdan seçin.
                    </p>
                  )}
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </main>
  )
}
