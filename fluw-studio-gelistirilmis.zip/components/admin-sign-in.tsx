'use client'

import { useActionState } from 'react'
import { signInAdmin, type SignInState } from '@/app/admin/sign-in/action'

const initialState: SignInState = { error: null }

export function AdminSignIn() {
  const [state, formAction, pending] = useActionState(signInAdmin, initialState)

  return (
    <main className="admin-auth-page">
      <section className="admin-auth-card" aria-labelledby="admin-login-title">
        <a className="wordmark" href="/" aria-label="Fluw Studio ana sayfa">fluw<span>®</span></a>
        <p className="eyebrow">FLUW STUDIO · YÖNETİM</p>
        <h1 id="admin-login-title">Yönetim<br /><em>paneli.</em></h1>
        <p className="admin-auth-copy">Devam etmek için yönetici hesabınızla giriş yapın.</p>
        <form action={formAction} className="admin-form">
          <label htmlFor="admin-email">E-posta</label>
          <input autoComplete="username" id="admin-email" name="email" type="email" required />
          <label htmlFor="admin-password">Şifre</label>
          <input autoComplete="current-password" id="admin-password" name="password" type="password" required />
          {state.error && <p className="admin-error" role="alert">{state.error}</p>}
          <button className="admin-primary-button" type="submit" disabled={pending}>
            {pending ? 'Giriş yapılıyor…' : 'Giriş yap'}
          </button>
        </form>
        <a className="admin-back-link" href="/admin/sign-up">İlk kez mi giriş yapıyorsunuz? Hesap oluşturun</a>
        <a className="admin-back-link" href="/">Mağazaya dön</a>
      </section>
    </main>
  )
}
