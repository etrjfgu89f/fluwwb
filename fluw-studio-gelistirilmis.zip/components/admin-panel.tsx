'use client'

import { useMemo, useState } from 'react'
import {
  Check,
  Copy,
  ExternalLink,
  Eye,
  EyeOff,
  Link2,
  Package,
  Search,
  ShoppingBag,
  Sparkles,
  TrendingUp,
} from 'lucide-react'
import {
  createProduct,
  deleteProduct,
  duplicateProduct,
  signOutAdmin,
  toggleProductStatus,
  updateProduct,
} from '@/app/admin/actions'
import type { products } from '@/lib/db/schema'
import type { ShopierOrder } from '@/lib/shopier'

type Product = typeof products.$inferSelect

type AdminPanelProps = {
  products: Product[]
  orders: ShopierOrder[]
  orderError: string | null
  email: string
  authMethod?: 'magic-link' | 'neon-auth'
}

const PRESET_IMAGES = [
  { label: 'Loop Vazo', url: '/product-vase.png' },
  { label: 'Mantar Lamba', url: '/product-lamp.png' },
  { label: 'Knot Heykel', url: '/product-knot.png' },
  { label: 'Dalga Kase', url: '/product-bowl.png' },
]

function money(amount: number, currency = 'TRY') {
  try {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount)
  } catch {
    return `${amount.toLocaleString('tr-TR')} ${currency}`
  }
}

function date(value: string | null) {
  if (!value) return '—'
  const parsed = new Date(value)
  return Number.isNaN(parsed.getTime())
    ? value
    : new Intl.DateTimeFormat('tr-TR', { dateStyle: 'medium', timeStyle: 'short' }).format(parsed)
}

function ProductFields({ product }: { product?: Product }) {
  const [imageUrl, setImageUrl] = useState(product?.imageUrl ?? '')

  return (
    <>
      {product && <input type="hidden" name="id" value={product.id} />}
      <label>
        Ürün adı
        <input name="name" defaultValue={product?.name ?? ''} required maxLength={120} placeholder="Örn: Dalga Vazo" />
      </label>
      <div className="admin-form-row">
        <label>
          Kategori
          <input name="category" defaultValue={product?.category ?? ''} required maxLength={60} placeholder="Objeler, Aydınlatma..." />
        </label>
        <label>
          Fiyat (₺)
          <input name="price" type="number" min="1" max="100000000" step="1" defaultValue={product?.price ?? ''} required placeholder="890" />
        </label>
      </div>
      <label>
        Açıklama
        <textarea name="description" defaultValue={product?.description ?? ''} rows={3} maxLength={2000} placeholder="Ürünün hikâyesi, ölçüleri veya malzemesi..." />
      </label>
      <label>
        Görsel yolu veya HTTPS adresi
        <input
          name="imageUrl"
          type="text"
          value={imageUrl}
          onChange={(e) => setImageUrl(e.target.value)}
          placeholder="https://… veya /product-vase.png"
        />
      </label>
      <div className="admin-preset-row" aria-label="Hazır stüdyo görselleri">
        {PRESET_IMAGES.map((preset) => (
          <button
            key={preset.url}
            type="button"
            className={`admin-preset-chip ${imageUrl === preset.url ? 'is-selected' : ''}`}
            onClick={() => setImageUrl(preset.url)}
          >
            {preset.label}
          </button>
        ))}
      </div>
      <label>
        Shopier ürün bağlantısı
        <input name="shopierUrl" type="url" defaultValue={product?.shopierUrl ?? ''} placeholder="https://www.shopier.com/…" />
      </label>
      <div className="admin-form-row">
        <label>
          Renk tonu
          <select name="tone" defaultValue={product?.tone ?? 'blue'}>
            <option value="blue">Mavi</option>
            <option value="pink">Pembe</option>
            <option value="green">Yeşil</option>
            <option value="yellow">Sarı</option>
          </select>
        </label>
        <label>
          Etiket
          <input name="tag" defaultValue={product?.tag ?? ''} maxLength={40} placeholder="Yeni, Çok sevilen…" />
        </label>
      </div>
      <label className="admin-checkbox">
        <input type="checkbox" name="active" defaultChecked={product?.active ?? true} /> Mağazada yayında
      </label>
    </>
  )
}

export function AdminPanel({ products, orders, orderError, email, authMethod = 'neon-auth' }: AdminPanelProps) {
  const [tab, setTab] = useState<'products' | 'orders'>('products')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'live' | 'draft'>('all')
  const [copiedLink, setCopiedLink] = useState(false)

  const stats = useMemo(() => {
    const liveCount = products.filter((p) => p.active).length
    const linkedCount = products.filter((p) => Boolean(p.shopierUrl)).length
    const revenue = orders.reduce((acc, o) => acc + (o.total ?? 0), 0)
    return { liveCount, linkedCount, revenue }
  }, [products, orders])

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesStatus =
        statusFilter === 'all' ||
        (statusFilter === 'live' && p.active) ||
        (statusFilter === 'draft' && !p.active)
      const q = search.trim().toLocaleLowerCase('tr')
      const matchesSearch =
        !q ||
        p.name.toLocaleLowerCase('tr').includes(q) ||
        p.category.toLocaleLowerCase('tr').includes(q)
      return matchesStatus && matchesSearch
    })
  }, [products, search, statusFilter])

  const copyQuickLoginLink = async () => {
    try {
      const quickUrl = `${window.location.origin}/admin-giris?omerasafsabaz.dev`
      await navigator.clipboard.writeText(quickUrl)
      setCopiedLink(true)
      window.setTimeout(() => setCopiedLink(false), 2000)
    } catch {
      // Clipboard fallback ignored
    }
  }

  return (
    <main className="admin-shell">
      <header className="admin-header">
        <a className="wordmark" href="/" aria-label="Fluw Studio ana sayfa">
          fluw<span>®</span>
        </a>
        <div className="admin-account">
          {authMethod === 'magic-link' && (
            <span className="admin-auth-badge" title="Hızlı giriş bağlantısı ile oturum açıldı">
              <Sparkles size={11} /> Hızlı Giriş
            </span>
          )}
          <span>{email}</span>
          <form action={signOutAdmin}>
            <button type="submit">Çıkış yap</button>
          </form>
        </div>
      </header>

      <section className="admin-main">
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">FLUW STUDIO · YÖNETİM</p>
            <h1>
              Merhaba, <em>stüdyo.</em>
            </h1>
            <p>Ürünlerinizi yönetin, Shopier siparişlerinizi ve mağaza performansını tek yerden takip edin.</p>
          </div>
          <div className="admin-heading-actions">
            <button
              type="button"
              className="admin-quick-copy-btn"
              onClick={copyQuickLoginLink}
              title="/admin-giris?omerasafsabaz.dev bağlantısını kopyala"
            >
              {copiedLink ? <Check size={13} /> : <Link2 size={13} />}
              {copiedLink ? 'Giriş linki kopyalandı' : 'Hızlı giriş linki'}
            </button>
            <a className="admin-store-link" href="/" target="_blank" rel="noopener noreferrer">
              Mağazayı görüntüle ↗
            </a>
          </div>
        </div>

        {/* KPI Özet Kartları */}
        <div className="admin-stats-grid" aria-label="Mağaza özeti">
          <div className="admin-stat-card">
            <div className="admin-stat-top">
              <span>YAYINDAKİ ÜRÜN</span>
              <Package size={14} />
            </div>
            <strong>
              {stats.liveCount} <small>/ {products.length}</small>
            </strong>
          </div>
          <div className="admin-stat-card">
            <div className="admin-stat-top">
              <span>SHOPIER BAĞLANTILI</span>
              <ExternalLink size={14} />
            </div>
            <strong>
              {stats.linkedCount} <small>/ {products.length}</small>
            </strong>
          </div>
          <div className="admin-stat-card">
            <div className="admin-stat-top">
              <span>SON 30 GÜN SİPARİŞ</span>
              <ShoppingBag size={14} />
            </div>
            <strong>{orders.length} adet</strong>
          </div>
          <div className="admin-stat-card">
            <div className="admin-stat-top">
              <span>SON 30 GÜN CİRO</span>
              <TrendingUp size={14} />
            </div>
            <strong>{money(stats.revenue)}</strong>
          </div>
        </div>

        <div className="admin-tabs" role="tablist" aria-label="Yönetim bölümleri">
          <button role="tab" aria-selected={tab === 'products'} onClick={() => setTab('products')}>
            Ürünler <span>{products.length}</span>
          </button>
          <button role="tab" aria-selected={tab === 'orders'} onClick={() => setTab('orders')}>
            Shopier siparişleri <span>{orders.length}</span>
          </button>
        </div>

        {tab === 'products' ? (
          <div className="admin-products-layout">
            <section className="admin-card admin-create-card" aria-labelledby="new-product-heading">
              <p className="eyebrow">YENİ KOLEKSİYON PARÇASI</p>
              <h2 id="new-product-heading">Ürün ekle</h2>
              <p className="admin-product-hint">
                Shopier ürün fiyatı ile mağaza fiyatını eşleştirin; bu alanlardan ödeme linki oluşturulmaz.
              </p>
              <form action={createProduct} className="admin-form">
                <ProductFields />
                <button className="admin-primary-button" type="submit">
                  Ürünü ekle
                </button>
              </form>
            </section>

            <section className="admin-products-list" aria-labelledby="products-heading">
              <div className="admin-list-heading">
                <div>
                  <p className="eyebrow">MAĞAZA KATALOĞU</p>
                  <h2 id="products-heading">
                    Ürünlerin <em>({filteredProducts.length})</em>
                  </h2>
                </div>

                <div className="admin-filter-bar">
                  <div className="admin-search-box">
                    <Search size={13} />
                    <input
                      type="search"
                      placeholder="Ürün veya kategori ara..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      aria-label="Ürün ara"
                    />
                  </div>
                  <div className="admin-status-pills" role="group" aria-label="Durum filtresi">
                    <button
                      type="button"
                      className={statusFilter === 'all' ? 'is-active' : ''}
                      onClick={() => setStatusFilter('all')}
                    >
                      Tümü
                    </button>
                    <button
                      type="button"
                      className={statusFilter === 'live' ? 'is-active' : ''}
                      onClick={() => setStatusFilter('live')}
                    >
                      Yayında
                    </button>
                    <button
                      type="button"
                      className={statusFilter === 'draft' ? 'is-active' : ''}
                      onClick={() => setStatusFilter('draft')}
                    >
                      Taslak
                    </button>
                  </div>
                </div>
              </div>

              {filteredProducts.length === 0 ? (
                <p className="admin-empty">Arama veya filtreye uygun ürün bulunamadı.</p>
              ) : (
                filteredProducts.map((product) => (
                  <details className="admin-product-row" key={product.id}>
                    <summary>
                      <img src={product.imageUrl || '/placeholder.svg'} alt="" />
                      <span className="admin-product-name">
                        <strong>{product.name}</strong>
                        <small>
                          {product.category}
                          {product.shopierUrl ? ' · Shopier bağlı' : ' · Bağlantı yok'}
                        </small>
                      </span>
                      <span className="admin-product-price">{product.price.toLocaleString('tr-TR')}₺</span>
                      <span className={product.active ? 'admin-status is-live' : 'admin-status'}>
                        {product.active ? 'Yayında' : 'Taslak'}
                      </span>
                      <span aria-hidden="true">⌄</span>
                    </summary>
                    <div className="admin-product-edit">
                      {/* Hızlı İşlem Çubuğu */}
                      <div className="admin-quick-bar">
                        <form action={toggleProductStatus}>
                          <input type="hidden" name="id" value={product.id} />
                          <input type="hidden" name="nextActive" value={String(!product.active)} />
                          <button type="submit" className="admin-mini-btn">
                            {product.active ? (
                              <>
                                <EyeOff size={12} /> Taslağa al
                              </>
                            ) : (
                              <>
                                <Eye size={12} /> Yayına al
                              </>
                            )}
                          </button>
                        </form>
                        <form action={duplicateProduct}>
                          <input type="hidden" name="id" value={product.id} />
                          <button type="submit" className="admin-mini-btn">
                            <Copy size={12} /> Kopyala
                          </button>
                        </form>
                        {product.shopierUrl && (
                          <a
                            href={product.shopierUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="admin-mini-btn"
                          >
                            <ExternalLink size={12} /> Shopier&apos;de aç
                          </a>
                        )}
                      </div>

                      <form action={updateProduct} className="admin-form">
                        <ProductFields product={product} />
                        <div className="admin-form-actions">
                          <button className="admin-primary-button" type="submit">
                            Değişiklikleri kaydet
                          </button>
                          {!product.active && (
                            <button className="admin-delete-button" formAction={deleteProduct} type="submit">
                              Ürünü sil
                            </button>
                          )}
                        </div>
                      </form>
                      <p className="admin-product-hint">
                        Mağaza fiyatı Shopier bağlantısındaki fiyatla aynı olmalı; Shopier&apos;de fiyat değiştirirseniz
                        burayı da güncelleyin. Bağlantı eklenene kadar satın alma butonu gösterilmez.
                      </p>
                    </div>
                  </details>
                ))
              )}
            </section>
          </div>
        ) : (
          <section className="admin-orders" aria-labelledby="orders-heading">
            <div className="admin-list-heading">
              <div>
                <p className="eyebrow">SON 30 GÜN</p>
                <h2 id="orders-heading">
                  Shopier <em>siparişleri.</em>
                </h2>
              </div>
              <span className="admin-orders-count">{orders.length} sipariş</span>
            </div>
            {orderError && (
              <p className="admin-order-error" role="status">
                {orderError}
              </p>
            )}
            {!orderError && orders.length === 0 ? (
              <p className="admin-empty">Son 30 günde Shopier siparişi bulunamadı.</p>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-orders-table">
                  <thead>
                    <tr>
                      <th>Sipariş</th>
                      <th>Müşteri</th>
                      <th>Ürünler</th>
                      <th>Tarih</th>
                      <th>Durum</th>
                      <th className="numeric">Tutar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map((order) => (
                      <tr key={order.id}>
                        <td>
                          <strong>#{order.id}</strong>
                        </td>
                        <td>
                          <span>{order.customer}</span>
                          {order.email && <small>{order.email}</small>}
                        </td>
                        <td>{order.itemSummary}</td>
                        <td>{date(order.createdAt)}</td>
                        <td>
                          <span className="admin-order-status">{order.status}</span>
                        </td>
                        <td className="numeric">{order.total === null ? '—' : money(order.total, order.currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="admin-order-note">
              Sipariş bilgileri Shopier hesabınızdan güvenli şekilde alınır. Tam ödeme ve kargo işlemleri Shopier
              panelinde yönetilir.
            </p>
          </section>
        )}
      </section>
    </main>
  )
}
