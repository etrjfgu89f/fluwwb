'use client'

import { useActionState } from 'react'
import { createAdminAccount, type SignUpState } from '@/app/admin/sign-up/action'

const initialState: SignUpState = { error: null }

export function AdminSignUp() {
  const [state, formAction, pending] = useActionState(createAdminAccount, initialState)

  return (
    <main className="admin-auth-page">
      <section className="admin-auth-card" aria-labelledby="admin-signup-title">
        <a className="wordmark" href="/" aria-label="Fluw Studio ana sayfa">fluw<span>®</span></a>
        <p className="eyebrow">FLUW STUDIO · YÖNETİM</p>
        <h1 id="admin-signup-title">Admin<br /><em>hesabı.</em></h1>
        <p className="admin-auth-copy">Hesap yalnızca projede tanımlı yönetici e-postası için oluşturulabilir.</p>
        <form action={formAction} className="admin-form">
          <label htmlFor="admin-email">Yönetici e-postası</label>
          <input autoComplete="username" id="admin-email" name="email" type="email" required />
          <label htmlFor="admin-password">Şifre</label>
          <input autoComplete="new-password" id="admin-password" name="password" type="password" minLength={8} maxLength={128} required />
          <label htmlFor="admin-confirm-password">Şifreyi doğrula</label>
          <input autoComplete="new-password" id="admin-confirm-password" name="confirmPassword" type="password" minLength={8} maxLength={128} required />
          {state.error && <p className="admin-error" role="alert">{state.error}</p>}
          <button className="admin-primary-button" type="submit" disabled={pending}>{pending ? 'Hesap oluşturuluyor…' : 'Yönetici hesabı oluştur'}</button>
        </form>
        <a className="admin-back-link" href="/admin/sign-in">Zaten hesabınız var mı? Giriş yapın</a>
        <a className="admin-back-link" href="/">Mağazaya dön</a>
      </section>
    </main>
  )
}
